package com.stringfunctions;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class InvokeUniqueURI extends AbstractMessageTransformer{
/* Some code below adapted from https://www.geeksforgeeks.org/determine-string-unique-characters/ */
	public static boolean UniqueURL(String struriParameter) 
	{
	    boolean isUnique = true;
	    //iterates through the string checking to see if the i value is equal to the j value
	    //If it is not, isUnique is false and the iterating stops.
	    for (int i = 0;i < struriParameter.length() && isUnique;i++ ) {
	      for (int j = i+1 ;j < struriParameter.length() && isUnique;j++ ) {
	        if(struriParameter.charAt(i) == struriParameter.charAt(j))
	        {
	          isUnique = false;
	        }
	      }
	    }
	    return isUnique;
  }
	
@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException 
	{
		//Calls the UniqueURL function and passes in the URI parameter; result of the function is returned
		boolean booluniquestr = UniqueURL((String)message.getInvocationProperty("inputString"));
		return booluniquestr;
	}

}

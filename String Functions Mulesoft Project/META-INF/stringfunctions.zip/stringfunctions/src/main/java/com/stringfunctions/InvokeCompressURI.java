package com.stringfunctions;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class InvokeCompressURI extends AbstractMessageTransformer
{
	@Override
	public String transformMessage(MuleMessage message, String outputEncoding) throws TransformerException 
	{
		//input string is taken from the URI parameter and passed into the program
		String struriparameterInput = (String)message.getInvocationProperty("inputString");
	    StringBuilder strbufffinalCompressed = new StringBuilder();
	    int counter = 1;
	    for(int i = 0; i < struriparameterInput.length() - 1; i++)
	    {
	      if(struriparameterInput.charAt(i) == struriparameterInput.charAt(i + 1))
	      {
	        counter++;
	      }else{
	    	//if multiple values will push when done iterating through.
	    	 strbufffinalCompressed.append(Character.toString(struriparameterInput.charAt(i))); 
	    	 strbufffinalCompressed.append(Integer.toString(counter));
	        counter = 1;
	      }
	    }
	    //if single values will push immediately.//if single values will push immediately.
	    strbufffinalCompressed.append(Character.toString(struriparameterInput.charAt(struriparameterInput.length() - 1))); 
	    strbufffinalCompressed.append(Integer.toString(counter));
	    return strbufffinalCompressed.toString();
    }
}

